import java.awt.Color;

public class Pemain {
    private String nama;
    private int posisi;
    private Color warna;

    public Pemain(String nama, Color warna) {
        this.nama = nama;
        this.warna = warna;
        this.posisi = 1;
    }

    public void gerak(int langkah) {
        this.posisi += langkah;
    }

    public void setPosisi(int posisiBaru) {
        this.posisi = posisiBaru;
    }

    public int getPosisi() {
        return posisi;
    }

    public String getNama() {
        return nama;
    }

    public Color getWarna() {
        return warna;
    }
}