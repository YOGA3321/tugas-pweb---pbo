import java.util.HashMap;
import java.util.Map;

public class LogikaPapan {
    private Map<Integer, Integer> aturan;

    public LogikaPapan() {
        aturan = new HashMap<>();
        isiDataPapan();
    }

    private void isiDataPapan() {
        //  DAFTAR TANGGA
        aturan.put(3, 20);
        aturan.put(6, 14);
        aturan.put(11, 28);
        aturan.put(15, 34);
        aturan.put(17, 74);
        aturan.put(22, 37);
        aturan.put(38, 59);
        aturan.put(49, 67);
        aturan.put(57, 76);
        aturan.put(61, 78);
        aturan.put(73, 86);
        aturan.put(81, 98);
        aturan.put(88, 91);
        //  DAFTAR ULAR
        aturan.put(8, 4);
        aturan.put(18, 1);
        aturan.put(26, 10);
        aturan.put(39, 5);
        aturan.put(51, 6);
        aturan.put(54, 36);
        aturan.put(56, 1);
        aturan.put(60, 23);
        aturan.put(75, 28);
        aturan.put(83, 45);
        aturan.put(85, 59);
        aturan.put(90, 38);
        aturan.put(92, 25);
        aturan.put(97, 87);
        aturan.put(99, 63);
    }

    public int cekTujuan(int posisiSekarang) {
        if (aturan.containsKey(posisiSekarang)) {
            return aturan.get(posisiSekarang);
        }
        return posisiSekarang;
    }

    public boolean isNaik(int awal, int akhir) {
        return akhir > awal;
    }
}