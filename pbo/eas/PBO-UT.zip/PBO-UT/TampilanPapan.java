import javax.swing.JPanel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;

public class TampilanPapan extends JPanel {
    private Image gambarBackground;
    private ArrayList<Pemain> paraPemain;
    
    private final int BOARD_SIZE = 600; 
    private final int CELL_SIZE = BOARD_SIZE / 10; 
    private final int PAWN_SIZE = 30; 

    public TampilanPapan(ArrayList<Pemain> pemain) {
        this.paraPemain = pemain;
        this.setPreferredSize(new Dimension(BOARD_SIZE, BOARD_SIZE));
        
        try {
            gambarBackground = ImageIO.read(new File("image_0.jpg")); 
        } catch (IOException e) {
            System.out.println("Gambar tidak ditemukan! Cek nama file.");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        if (gambarBackground != null) {
            g2d.drawImage(gambarBackground, 0, 0, BOARD_SIZE, BOARD_SIZE, this);
        }

        int offset = 0;
        for (Pemain p : paraPemain) {
            Point koordinat = getKoordinat(p.getPosisi());
            g2d.setColor(p.getWarna());
            g2d.fillOval(koordinat.x + offset, koordinat.y + offset, PAWN_SIZE, PAWN_SIZE);
            
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawOval(koordinat.x + offset, koordinat.y + offset, PAWN_SIZE, PAWN_SIZE);
            
            offset += 5;
        }
    }

    private Point getKoordinat(int posisi) {
        if (posisi <= 0) posisi = 1;
        if (posisi > 100) posisi = 100;

        int rowFromBottom = (posisi - 1) / 10;
        int col;
        
        if (rowFromBottom % 2 == 0) {
            col = (posisi - 1) % 10;
        } else {
            col = 9 - ((posisi - 1) % 10);
        }

        int visualRow = 9 - rowFromBottom;
        int x = col * CELL_SIZE + (CELL_SIZE - PAWN_SIZE) / 2;
        int y = visualRow * CELL_SIZE + (CELL_SIZE - PAWN_SIZE) / 2;

        return new Point(x, y);
    }
}