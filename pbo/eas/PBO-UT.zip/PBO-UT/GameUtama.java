import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

public class GameUtama extends JFrame {
    private ArrayList<Pemain> pemain;
    private LogikaPapan logika;
    private TampilanPapan tampilan;
    
    private int giliranIndex = 0;
    private Random dadu = new Random();
    private boolean selesai = false;

    private JTextArea logArea;
    private JButton btnDadu;
    private JLabel lblStatus;

    public GameUtama() {
        super("Ular Tangga BlueJ");
        
        pemain = new ArrayList<>();
        pemain.add(new Pemain("Merah", Color.RED));
        pemain.add(new Pemain("Biru", Color.BLUE));
        
        logika = new LogikaPapan();
        tampilan = new TampilanPapan(pemain);

        setupLayout();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void setupLayout() {
        setLayout(new BorderLayout());

        add(tampilan, BorderLayout.CENTER);

        JPanel panelKanan = new JPanel(new BorderLayout());
        panelKanan.setPreferredSize(new Dimension(250, 600));
        panelKanan.setBorder(new EmptyBorder(10, 10, 10, 10));

        lblStatus = new JLabel("Giliran: Merah");
        lblStatus.setFont(new Font("Arial", Font.BOLD, 16));
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
        panelKanan.add(lblStatus, BorderLayout.NORTH);

        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setLineWrap(true);
        panelKanan.add(new JScrollPane(logArea), BorderLayout.CENTER);

        btnDadu = new JButton("LEMPAR DADU");
        btnDadu.setBackground(Color.GREEN);
        btnDadu.setFont(new Font("Arial", Font.BOLD, 14));
        btnDadu.addActionListener(e -> mainkanGiliran());
        panelKanan.add(btnDadu, BorderLayout.SOUTH);

        add(panelKanan, BorderLayout.EAST);
    }

    private void mainkanGiliran() {
        if (selesai) return;

        Pemain p = pemain.get(giliranIndex);
        int nilai = dadu.nextInt(6) + 1;
        
        log("----------------");
        log(p.getNama() + " melempar: " + nilai);
 
        p.gerak(nilai);
        if (p.getPosisi() > 100) p.setPosisi(100);

        int posisiBaru = logika.cekTujuan(p.getPosisi());
        if (posisiBaru != p.getPosisi()) {
            if (logika.isNaik(p.getPosisi(), posisiBaru)) {
                log("Hore! Naik Tangga ke " + posisiBaru);
            } else {
                log("Aduh! Digigit Ular ke " + posisiBaru);
            }
            p.setPosisi(posisiBaru);
        } else {
            log("Posisi sekarang: " + p.getPosisi());
        }

        tampilan.repaint();

        if (p.getPosisi() == 100) {
            JOptionPane.showMessageDialog(this, p.getNama() + " Menang!");
            selesai = true;
            btnDadu.setEnabled(false);
        } else {
            giliranIndex = (giliranIndex + 1) % pemain.size();
            lblStatus.setText("Giliran: " + pemain.get(giliranIndex).getNama());
        }
    }

    private void log(String text) {
        logArea.append(text + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    public static void main(String[] args) {
        new GameUtama();
    }
}